from distutils.core import setup

setup(
    name='spookyaction',
    version='0.2.1',
    author='Adam Short',
    author_email='adam010101@icloud.com',
    packages=['spookyaction'],
    url='https://github.com/adam-short/spookyaction',
    license='LICENSE.txt',
    description='A framework for pyautogui automation.',
    long_description="See GitHub for more.",
)
