===========
SpookyAction
===========

SpookyAction is a software package for rapid development of automation solutions.
It is currently in alpha stage and as such is particularly buggy and with few features.
